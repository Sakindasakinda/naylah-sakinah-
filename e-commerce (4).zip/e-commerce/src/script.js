// Data produk
const products = [
    { id: 1, name: 'Product 1', description: 'This is product 1', price: '$10', image: 'https://via.placeholder.com/200' },
    { id: 2, name: 'Product 2', description: 'This is product 2', price: '$15', image: 'https://via.placeholder.com/200' },
    { id: 3, name: 'Product 3', description: 'This is product 3', price: '$20', image: 'https://via.placeholder.com/200' }
];

// Fungsi untuk menampilkan daftar produk
function loadProducts() {
    const productList = document.querySelector('.product-list');
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.classList.add('product-card');
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p><strong>${product.price}</strong></p>
            <button onclick="viewProductDetail(${product.id})">View Details</button>
        `;
        productList.appendChild(productCard);
    });
}

// Fungsi untuk menampilkan detail produk
function viewProductDetail(productId) {
    const product = products.find(p => p.id === productId);
    const productDetail = document.getElementById('product-detail');
    const detailContent = document.getElementById('detail-content');

    detailContent.innerHTML = `
        <h2>${product.name}</h2>
        <img src="${product.image}" alt="${product.name}">
        <p>${product.description}</p>
        <p><strong>${product.price}</strong></p>
        <button onclick="showCheckoutForm()">Buy Now</button>
    `;
    
    document.querySelector('#product-list').style.display = 'none';
    productDetail.style.display = 'block';
}

// Fungsi untuk kembali ke halaman produk
function goBack() {
    document.querySelector('#product-list').style.display = 'flex';
    document.getElementById('product-detail').style.display = 'none';
}

// Fungsi untuk menampilkan formulir checkout
function showCheckoutForm() {
    document.getElementById('checkout-form').style.display = 'block';
}

// Fungsi untuk menyelesaikan pembelian
document.getElementById('checkout').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const address = document.getElementById('address').value;

    alert(`Thank you for your purchase, ${name}! We will send your order to ${address}.`);
    document.getElementById('checkout-form').reset();
    document.getElementById('checkout-form').style.display = 'none';
});

// Memuat produk saat halaman dibuka
loadProducts();